<?php include_once 'config/init.php' ?>


<?php
$ksr = new DN;
$template = new Template('templates/ajax.php');



    
echo $template;
?>