$(document).ready(function() {
    $('.user_registration').click(function(event) {
        $('.chat_box').toggleClass('active');
    });

    $('#conv-form-wrapper').convform({ selectInputStyle: 'disable' });
})
$(document).ready(function() {
    $("#tableSearch").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});