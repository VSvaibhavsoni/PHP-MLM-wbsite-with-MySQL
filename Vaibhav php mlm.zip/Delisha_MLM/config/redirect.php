    <?php 
    session_start();
    $db_host = 'localhost';
    $db_user = 'root';
    $db_pass = '';
    $db_name = 'sp';

 $conn =mysqli_connect($db_host,$db_user,$db_pass,$db_name);
   // $check_alert="true";
    //$_SESSION['check_alert']=$check_alert;

if(!$conn){
    echo "<script>alert('not connected');</script>";
}

    if(isset($_REQUEST['login'])){
        
    $user_id =$_REQUEST['user_id'];
    $password =$_REQUEST['password'];

    move_to_dashboard($user_id, $password);
   
    }
   

    if (isset($_REQUEST['user_registration'])) {
    $s_id=$_REQUEST['sponsor_id'];
    $pin=$_REQUEST['pin'];
    $name=$_REQUEST['user_name'];
    $email=$_REQUEST['user_email'];
    $pos=$_REQUEST['position'];
    $mobile=$_REQUEST['user_mob'];
    $password=$_REQUEST['password'];


    if (check_pin($pin,$s_id)) {
    # code...
    insert_into_users($s_id,$name,$email,$pos,$mobile,$password);
    
    #binary_count($s_id,$pos);
    } else {
    echo '<script>alert("INVALID PIN / USED PIN");window.location.assign("../registration.php");</script>';
   
    }
    //echo '<script>window.location.assign("../registration.php");</script>';
  
    
    }

    //GENERATING PINS
    if (isset($_REQUEST['generate_pin'])) {
     $my_id=$_SESSION['user_id'];
 //  include_once("connection.php");
         generate_pin($my_id);
        }

    //CHECKING WALLETS
    if (isset($_REQUEST['withdraw_money'])) {
        $s_id=$_REQUEST['sponsor_id'];      
        $name=$_REQUEST['acc_name'];
        $acc_no=$_REQUEST['acc_no'];
        $acc_ifsc=$_REQUEST['acc_ifsc'];
        $amount=$_REQUEST['amount'];
    check_wallet($s_id,$name,$acc_no,$acc_ifsc,$amount);

    }

    //PAYMENT REQUEST DEKH LO FRIENDS
    //Approve
    if (isset($_REQUEST['accept_payment_req'])) {
        $user_id=$_REQUEST['user_id'];      
        $date=$_REQUEST['date'];
        $amount=$_REQUEST['amount'];
        $approving_date =date("y-m-d");
     
        mysqli_query($conn,"UPDATE `pay_req` SET `status`= '1'  WHERE `user_id`='$user_id' AND `app_date`='$date' ");
         mysqli_query($conn,"UPDATE `pay_req` SET `approving_date`= '$approving_date'  WHERE `user_id`='$user_id' AND `app_date`='$date' ");
        
        mysqli_query($conn,"UPDATE `users` SET `wallet`= `wallet`-'$amount'  WHERE `user_id`='$user_id' ");
        echo '<script>
    alert(" Request Accepted <'.$approving_date.'>");window.location.assign("../paymentreq.php");
    </script>';
    }

    //decline
    if (isset($_REQUEST['decline_payment_req'])) {
        $user_id=$_REQUEST['user_id'];      
        $date=$_REQUEST['date'];
        $approving_date =date("y-m-d");
        mysqli_query($conn,"UPDATE `pay_req` SET `status`= '2'    WHERE `user_id`='$user_id' AND `app_date`='$date' ");
        
        mysqli_query($conn,"UPDATE `pay_req` SET `decline_date`= '$approving_date'  WHERE `user_id`='$user_id' AND `app_date`='$date' ");
        mysqli_query($conn,"INSERT INTO `pay_req`(`decline_date`) VALUES ('$approving_date')  WHERE `user_id`='$user_id' AND `app_date`='$date' ");
        
        echo '<script>
        alert(" Request Declined  <'.$approving_date.'>");window.location.assign("../paymentreq.php");
        </script>';

    }
  

        //Binary Counting
    function binary_count($spons,$pos){
    global $conn;
    if ($pos==0) {
    $pos="left_count";

    }else{
    $pos="right_count";
    }
    while($spons!=0)
    {
    mysqli_query($conn,"UPDATE `users` SET `$pos`= `$pos`+1 WHERE `user_id`='$spons' ");
    is_pair_generated($spons);

    $pos=find_position($spons);
    $spons=find_placement_id($spons);

    }
    }



    //checking pairs
    function is_pair_generated($spons){
    global $conn;
    $pla_data=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `users` WHERE `user_id`='$spons' "));
    if($pla_data['left_count']==$pla_data['right_count']){
    $date=date("y-m-d");
    $data=mysqli_query($conn,"SELECT * FROM `pair_count` WHERE `date`='$date' AND `user_id`='$spons'");
    if (mysqli_num_rows($data)==1) {
    mysqli_query($conn,"UPDATE `pair_count` SET `no_of_pair`=`no_of_pair`+1 WHERE `date`='$date' AND `user_id`='$spons'");

    }else {
    mysqli_query($conn,"INSERT INTO `pair_count`( `user_id`, `date`, `no_of_pair`) VALUES ('$spons','$date','1')");

    }
    }
    }

    //CHECKING PINS
    function check_pin($pin,$s_id){
    global $conn;
    $query = mysqli_query($conn,"SELECT * FROM `pin` WHERE `pin_value`='$pin' AND `status`!='1' AND
    `allocate_users`='$s_id'");
    if(mysqli_num_rows($query) > 0 ){
    mysqli_query($conn,"UPDATE `pin` SET `status`='1' WHERE `pin_value`= '$pin' ");
    return true;
    }
    return false;
    }



    //INSERTING DATA
    function insert_into_users($s_id,$name,$email,$pos,$mobile,$password){
    global $conn;
    $user_id=rand(11111111,99999999);
    $date=date("y-m-d");
    mysqli_query($conn,"INSERT INTO `users`( `user_id`, `name`, `email`, `password`, `mobile`, `position`,
    `sponsor_id`,`date`) VALUES ('$user_id','$name', '$email','$password','$mobile','$pos','$s_id','$date')");
    level_distribution($s_id);
    level_income($s_id);
    placement_id($user_id,$s_id,$pos);
    send_email($user_id,$name,$email,$password,$s_id);
  

    }


    //SENDING EMAILS
    function send_email($user_id,$name,$email,$password,$s_id){

    global $conn;
    $added_by=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `users` WHERE `user_id`='$s_id' "));
    $header1=$added_by['email'];
    $header="From: $header1 ";
    $subject = 'You were Added to MLM Plane By'.$added_by['name'];
    $message = 'Name ' .$name. "  User ID " .$user_id. "  Password:" .$password. "  Add More Users To your Account To Generate
    Income";
    if( mail($email,$subject,$message,$header)){
    echo '<script>
    alert("New Users User ID and Password Sended to their Email:- <'.$email.'> ");
    </script>';
    }else {
    echo '<script>
    alert(" Problem In Sending Email to:-<'.$email.'>");
    </script>';
    }
    }

    //GENERATING PLACEMENT ID
    function placement_id($user_id,$s_id,$pos){
    global $conn;

    $spons_data=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `users` WHERE `user_id`='$s_id' "));
    if($pos==0){
    if ($spons_data['left_side']==0) {

    mysqli_query($conn,"UPDATE `users` SET `left_side`='$user_id' WHERE `user_id`= '$s_id' ");
    mysqli_query($conn,"UPDATE `users` SET `placement_id`='$s_id' WHERE `user_id`= '$user_id' ");

    binary_count($s_id,$pos);
    }else {
    placement_id($user_id,$spons_data['left_side'],$pos);
    }

    }else {


    if ($spons_data['right_side']==0) {

    mysqli_query($conn,"UPDATE `users` SET `right_side`='$user_id' WHERE `user_id`= '$s_id' ");
    mysqli_query($conn,"UPDATE `users` SET `placement_id`='$s_id' WHERE `user_id`= '$user_id' ");

    binary_count($s_id,$pos);
    }else {
    placement_id($user_id,$spons_data['right_side'],$pos);
    }

    }
    }


    //GIVING LEVEL
        function level_income($s_id){
            
            global $conn;
           
            
            while ( $s_id!=0) {
                $count=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `users` WHERE `user_id`='$s_id' "));
                $income_percentage= ($count['left_count'] + $count['right_count']);
            
            
                            if ($income_percentage>=10 && $income_percentage<20 ) {
                                $level_income=1;
                            } elseif ($income_percentage>=20 && $income_percentage<30) {
                                $level_income=2;
                            }elseif ($income_percentage>=30 && $income_percentage<40) {
                                $level_income=3;
                            }elseif ($income_percentage>=40 && $income_percentage<50) {
                                $level_income=4;
                            }elseif ($income_percentage>=50 && $income_percentage<60) {
                                $level_income=5;
                            }elseif ($income_percentage>=60 && $income_percentage<70) {
                                $level_income=6;
                            }elseif ($income_percentage>=70 && $income_percentage<80) {
                                $level_income=7;
                            }elseif ($income_percentage>=80 && $income_percentage<90) {
                                $level_income=8;
                            }elseif ($income_percentage>=90 && $income_percentage<100) {
                                $level_income=9;
                            }elseif ($income_percentage>=100 ) {
                                $level_income=10;
                            }else {
                                $level_income=0;
                            }
                            mysqli_query($conn,"UPDATE `users` SET `level_income`='$level_income' WHERE `user_id`='$s_id' ");
                            $next_id= find_sponsor_id($s_id);
                            $s_id=$next_id;
                            
                            
            }
            
                        
        }
            
        



        function level_distribution($s_id){
        global $conn;
        $a=0;
        $RS_value=100;
        $income_per=[10,5,3,2,1,0.50,0.25,0.25,0.20,0.20,0.20,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10,0.10];
        while ($a < 25 && $s_id!=0) {
            $income_percentage=($income_per[$a]/100)*$RS_value;
            mysqli_query($conn,"UPDATE `users` SET `wallet`=`wallet`+$income_percentage WHERE `user_id`='$s_id' ");
                    $next_id= find_sponsor_id($s_id);
                    $s_id=$next_id;
                    $a++ ;
                    
                }
            }





        function find_sponsor_id($s_id){
            global $conn;
            $data= mysqli_fetch_array( mysqli_query($conn," SELECT * FROM `users` WHERE `user_id`='$s_id' "));
            return $data['sponsor_id'];
        }






        function find_placement_id($s_id){
            global $conn;
            $data= mysqli_fetch_array( mysqli_query($conn," SELECT * FROM `users` WHERE `user_id`='$s_id' "));
            return $data['placement_id'];
        }






        function find_position($s_id){
            global $conn;
            $data=mysqli_fetch_array(mysqli_query($conn," SELECT * FROM `users` WHERE `user_id`='$s_id' "));
            $pos=$data['position'];
            if ($pos==0) {
                $pos=" left_count"; }else{ $pos="right_count" ; 
                } 
                return $pos;
            } 



                    


        function move_to_dashboard($user_id,$pass){
            global $conn; $query=mysqli_query($conn,"SELECT * FROM `users` WHERE `user_id`='$user_id' AND `password`='$pass'");
            
            if(mysqli_num_rows($query) == 1){
            $_SESSION['session_id'] = session_id();
            $_SESSION['user_id'] = $user_id;
            redirect("../dashboard.php", "Log IN", "success");
            //echo '<script>alert("Login Success");window.location.assign("../dashboard.php");</script>';
            //header("Location: ../dashboard.php");
            } else{
                    echo '<script>alert("Wrong credentials");window.location.assign("../index.php");</script>';
                    
                }
                } 






            function generate_pin($my_id){
                global $conn;
                $r_pin=rand(111111,999999);
                mysqli_query($conn, "INSERT INTO `pin` (`pin_value`, `allocate_users`,`status`) VALUES ('$r_pin','$my_id','0')");
    
                echo '<script>alert("Generated pin ' .$r_pin.' for ID ' .$my_id.' ");window.location.assign("../generate_pin.php");</script>';
            }






                function check_wallet($s_id,$name,$acc_no,$acc_ifsc,$amount){

                global $conn;
                $data=mysqli_fetch_array(mysqli_query($conn," SELECT * FROM `users` WHERE `user_id`='$s_id' "));

                   if($data['wallet']>=$amount  ){
                        if($data['wallet']>=500){
                            
                        $data=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `users` WHERE `user_id`='$s_id' "));
                        $spons_name=$data['sponsor_id'];

                        mysqli_query($conn,"INSERT INTO `pay_req`( `user_id`, `sponsor_id`, `acc_name`, `acc_no`, `acc_ifsc`, `amount`,`status`) VALUES ('$s_id','$spons_name','$name','$acc_no','$acc_ifsc','$amount','0')");

                        echo '<script>alert("Your Request has been registered ");window.location.assign("../withdraw.php");</script>';

                    }else{
                        echo '<script>alert("Minimum 500/- Needed In Wallet To Complete Transaction");window.location.assign("../withdraw.php");</script>';
                            }
                    }else{
                echo '<script>alert("Insufficient Balance ");window.location.assign("../withdraw.php");</script>';
               
                    }
            }
            
            function redirect($page =FALSE, $message=NULL, $message_type = NULL){
                if(is_string ($page)){
                    $location = $page;
                }else{
                    $location = $_SERVER['SCRIPT_NAME'];
                }
        
                if($message != NULL){
                    $_SESSION['message']= $message;
                }
        
                if($message_type != NULL){
                    $_SESSION['message_type'] = $message_type;
                }
        
                header("Location: ".$location);
                exit;
            }

            ?>