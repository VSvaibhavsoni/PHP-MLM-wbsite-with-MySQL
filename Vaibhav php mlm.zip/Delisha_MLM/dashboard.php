<?php include_once 'config/init.php' ?>


<?php
$ksr = new DN;
$template = new Template('templates/dashboard.php');



    
echo $template;
?>