<?php include_once 'config/init.php' ?>


<?php
$ksr = new DN;
$template = new Template('templates/generate_pin.php');



    
echo $template;
?>